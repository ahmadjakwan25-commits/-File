@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)

package com.smartfm.app

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import coil.compose.AsyncImage
import java.io.File

fun titleOf(s: String) = when (s) {
    "home" -> tr("স্মার্ট ফাইল ম্যানেজার", "Smart File Manager")
    "files" -> tr("ফাইল", "Files"); "search" -> tr("সার্চ", "Search"); "tools" -> tr("টুলস", "Tools")
    "settings" -> tr("সেটিংস", "Settings"); "cats" -> tr("ক্যাটাগরি", "Categories")
    "storage" -> tr("স্টোরেজ বিশ্লেষণ", "Storage analysis"); "bin" -> tr("রিসাইকেল বিন", "Recycle bin")
    "fav" -> tr("ফেভারিট", "Favorites"); "dups" -> tr("ডুপ্লিকেট ফাইল", "Duplicates")
    "sus" -> tr("সন্দেহজনক ফাইল", "Suspicious files"); "quar" -> "Virus_Quarantine"
    "priv" -> tr("প্রাইভেট ফোল্ডার", "Private folder"); "cloud" -> tr("ক্লাউড স্টোরেজ", "Cloud storage")
    "apk" -> "APK"; "zips" -> tr("ZIP ও আর্কাইভ", "ZIP & archives"); else -> s
}
val MAIN = listOf("home" to "🏠", "files" to "📁", "search" to "🔍", "tools" to "🧰", "settings" to "⚙️")

@Composable fun App(vm: VM, act: MainActivity) {
    val view = LocalView.current
    val barColor = (if (vm.dark) DarkBg else LightBg).toArgb()
    SideEffect {
        val w = act.window
        w.statusBarColor = barColor; w.navigationBarColor = barColor
        WindowCompat.getInsetsController(w, view).apply { isAppearanceLightStatusBars = !vm.dark; isAppearanceLightNavigationBars = !vm.dark }
    }
    AppTheme(vm.dark) {
        AppBackground {
            Surface(Modifier.fillMaxSize(), color = Color.Transparent, contentColor = MaterialTheme.colorScheme.onBackground) {
                when {
                    !act.granted -> PermScreen(act)
                    vm.locked -> LockScreen(vm, act)
                    else -> Main(vm, act)
                }
            }
        }
    }
}

@Composable fun HeroIcon(icon: String) {
    Box(Modifier.size(104.dp).clip(CircleShape).background(heroBrush()), contentAlignment = Alignment.Center) {
        Box(Modifier.size(88.dp).clip(CircleShape).background(Color.White.copy(alpha = .16f)), contentAlignment = Alignment.Center) { Text(icon, fontSize = 44.sp) }
    }
}

@Composable fun PermScreen(act: MainActivity) {
    Column(Modifier.fillMaxSize().padding(28.dp), Arrangement.Center, Alignment.CenterHorizontally) {
        HeroIcon("📁")
        Spacer(Modifier.height(22.dp))
        Text(tr("সব ফাইল দেখার অনুমতি দরকার", "All-files access is required"), style = MaterialTheme.typography.titleLarge, textAlign = TextAlign.Center)
        Spacer(Modifier.height(10.dp))
        Text(tr("ফোনের ফাইল দেখা, কপি, সরানো ও মোছার জন্য এই অনুমতি লাগে। ফাইল আপনার ফোনের বাইরে যায় না।", "Needed to browse, copy, move and delete files. Your files never leave the phone."),
            textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(26.dp))
        GradientButton(tr("অনুমতি দিন", "Grant access")) { act.requestAccess() }
    }
}

@Composable fun LockScreen(vm: VM, act: MainActivity) {
    var t by remember { mutableStateOf("") }; var err by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { if (vm.bio) act.biometric { vm.locked = false } }
    Column(Modifier.fillMaxSize().padding(28.dp), Arrangement.Center, Alignment.CenterHorizontally) {
        HeroIcon("🔒")
        Spacer(Modifier.height(22.dp))
        OutlinedTextField(t, { t = it; err = false }, singleLine = true, shape = RoundedCornerShape(16.dp), label = { Text(tr("পিন", "PIN")) }, isError = err,
            visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword))
        if (err) Text(tr("ভুল পিন", "Wrong PIN"), color = MaterialTheme.colorScheme.error)
        Spacer(Modifier.height(18.dp))
        GradientButton(tr("খুলুন", "Unlock")) { if (sha(t) == vm.pin) vm.locked = false else err = true }
        if (vm.bio) {
            Spacer(Modifier.height(10.dp))
            Pill("👆 " + tr("ফিঙ্গারপ্রিন্ট", "Fingerprint")) { act.biometric { vm.locked = false } }
        }
    }
}

@Composable fun Main(vm: VM, act: MainActivity) {
    val cs = MaterialTheme.colorScheme
    LaunchedEffect(Unit) { vm.scan() }
    LaunchedEffect(vm.screen) { if (vm.screen != "priv") vm.privOK = false }
    BackHandler(enabled = vm.screen != "home" || vm.selMode) {
        when {
            vm.selMode -> vm.clearSel()
            vm.screen == "files" && vm.cwd != P.root -> vm.cwd = vm.cwd.parentFile ?: P.root
            vm.stack.isNotEmpty() -> vm.back()
            else -> vm.nav("home")
        }
    }
    Scaffold(containerColor = Color.Transparent, topBar = { TopBar(vm) }, bottomBar = {
        Column {
            if (vm.selMode && vm.sel.isNotEmpty()) BulkBar(vm, act)
            FloatingNav(MAIN, vm.screen, { k -> if (k == "home") tr("হোম", "Home") else titleOf(k) }) { vm.nav(it) }
        }
    }) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (vm.screen) {
                "home" -> HomeScreen(vm); "files" -> FilesScreen(vm); "cats" -> CatsScreen(vm); "search" -> SearchScreen(vm)
                "tools" -> ToolsScreen(vm); "settings" -> SettingsScreen(vm, act); "storage" -> StorageScreen(vm)
                "bin" -> BinScreen(vm); "fav" -> FavScreen(vm); "dups" -> DupsScreen(vm); "sus" -> SusScreen(vm)
                "quar" -> QuarScreen(vm); "priv" -> PrivScreen(vm, act); "cloud" -> CloudScreen(vm)
                "apk" -> ListScreen(vm, vm.all.filter { it.extension.equals("apk", true) })
                "zips" -> ListScreen(vm, vm.all.filter { catOf(it) == Cat.ARC })
            }
        }
    }
    DialogHost(vm)
}

@Composable fun TopBar(vm: VM) {
    val main = MAIN.any { it.first == vm.screen }
    if (vm.screen == "home") {
        Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 14.dp, top = 16.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(tr("আসসালামু আলাইকুম 👋", "Welcome back 👋"), fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(titleOf("home"), fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            RoundBtn("🔍") { vm.go("search") }
        }
        return
    }
    TopAppBar(title = { Text(titleOf(vm.screen), maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Bold) },
        navigationIcon = { if (!main) Box(Modifier.padding(start = 12.dp)) { RoundBtn("←") { vm.back() } } },
        actions = { if (vm.screen != "search") RoundBtn("🔍") { vm.go("search") }; Spacer(Modifier.width(12.dp)) },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent, scrolledContainerColor = Color.Transparent))
}

@Composable fun BulkBar(vm: VM, act: MainActivity) {
    val ctx = LocalContext.current
    Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 6.dp).clip(RoundedCornerShape(22.dp)).background(MaterialTheme.colorScheme.primaryContainer)
        .horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Text(num("${vm.sel.size}"), fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 8.dp), color = MaterialTheme.colorScheme.onPrimaryContainer)
        TextButton(onClick = { val f = vm.selFiles(); vm.dlg = Dlg.Pick { d -> vm.copy(f, d) }; vm.clearSel() }) { Text("📋 " + tr("কপি", "Copy")) }
        TextButton(onClick = { val f = vm.selFiles(); vm.dlg = Dlg.Pick { d -> vm.move(f, d) }; vm.clearSel() }) { Text("📂 " + tr("সরান", "Move")) }
        TextButton(onClick = { shareFiles(ctx, vm.selFiles()); vm.clearSel() }) { Text("📤 " + tr("শেয়ার", "Share")) }
        TextButton(onClick = { vm.zip(vm.selFiles()); vm.clearSel() }) { Text("🗜️ ZIP") }
        TextButton(onClick = { vm.selFiles().forEach { f -> if (f.absolutePath !in vm.favs) vm.toggleFav(f) }; vm.clearSel() }) { Text("⭐") }
        TextButton(onClick = { val f = vm.selFiles(); vm.dlg = Dlg.Sure(tr("${num("${f.size}")}টি আইটেম রিসাইকেল বিনে যাবে।", "${f.size} items go to the recycle bin.")) { vm.trash(f) }; vm.clearSel() }) { Text("🗑️") }
        TextButton(onClick = { vm.clearSel() }) { Text("✕") }
    }
}

// ---------- shared pieces ----------
@Composable fun Donut(p: Float, size: Dp, label: String, onHero: Boolean = false) {
    val cs = MaterialTheme.colorScheme
    val track = if (onHero) Color.White.copy(alpha = .22f) else cs.surfaceVariant
    val arc = if (onHero) Brush.linearGradient(listOf(Color.White, Color(0xFFBFF4FF)))
    else Brush.linearGradient(listOf(cs.primary, cs.tertiary, cs.secondary))
    Box(Modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize().padding(8.dp)) {
            val w = 12.dp.toPx()
            drawArc(track, -90f, 360f, false, style = Stroke(w))
            drawArc(arc, -90f, 360f * p.coerceIn(0.01f, 1f), false, style = Stroke(w, cap = StrokeCap.Round))
        }
        Text(label, fontWeight = FontWeight.Bold, fontSize = 18.sp, color = if (onHero) Color.White else cs.onSurface)
    }
}

@Composable fun Thumb(f: File, sel: Boolean, mode: Boolean, size: Dp = 46.dp) {
    val cc = if (f.isDirectory) Color(0xFFFF9F43) else catColor(catOf(f))
    val sh = RoundedCornerShape(size * 0.28f)
    val base = if (f.isDirectory) Modifier.size(size).clip(sh).background(FolderBrush) else Modifier.size(size).clip(sh).background(cc.copy(alpha = .16f))
    Box(base, contentAlignment = Alignment.Center) {
        if (mode) Text(if (sel) "✅" else "⬜", fontSize = 22.sp)
        else if (f.isFile && catOf(f) == Cat.IMG) AsyncImage(f, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Text(if (f.isDirectory) "📁" else catOf(f).icon, fontSize = (size.value * 0.48f).sp)
    }
}

fun metaOf(vm: VM, f: File): String {
    if (f.isDirectory) return num("${f.list()?.size ?: 0}") + tr("টি আইটেম", " items")
    return listOfNotNull(if (vm.showSize) sizeStr(f.length()) else null, if (vm.showDate) dateStr(f.lastModified()) else null).joinToString(" · ")
}

@Composable fun FileItem(vm: VM, f: File, sub: String? = null, trailing: @Composable RowScope.() -> Unit = {}, onClick: (() -> Unit)? = null) {
    val sel = f.absolutePath in vm.sel; val warn = f.isFile && why(f).isNotEmpty()
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp).panel(RoundedCornerShape(18.dp), sel)
        .combinedClickable(onClick = { if (vm.selMode) vm.toggleSel(f) else (onClick ?: { vm.tap(f) })() }, onLongClick = { vm.selMode = true; if (!sel) vm.toggleSel(f) })
        .padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
        Thumb(f, sel, vm.selMode)
        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            Text((if (f.absolutePath in vm.favs) "⭐ " else "") + (if (warn) "⚠️ " else "") + f.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
            Text(sub ?: metaOf(vm, f), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        trailing()
    }
}

@Composable fun GridCell(vm: VM, f: File) {
    val sel = f.absolutePath in vm.sel
    Column(Modifier.padding(4.dp).panel(RoundedCornerShape(18.dp), sel)
        .combinedClickable(onClick = { if (vm.selMode) vm.toggleSel(f) else vm.tap(f) }, onLongClick = { vm.selMode = true; if (!sel) vm.toggleSel(f) }).padding(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally) {
        Thumb(f, sel, vm.selMode, 72.dp)
        Spacer(Modifier.height(4.dp))
        Text(f.name, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
        if (f.isFile && vm.showSize) Text(sizeStr(f.length()), fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable fun ItemRow(icon: String, title: String, sub: String? = null, tint: Color = MaterialTheme.colorScheme.primary, onClick: () -> Unit = {}, trailing: @Composable RowScope.() -> Unit = {}) {
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp).panel(RoundedCornerShape(18.dp)).clickable(onClick = onClick).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically) {
        IconBadge(icon, tint, 46.dp)
        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            Text(title, fontWeight = FontWeight.SemiBold)
            if (sub != null) Text(sub, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        trailing()
    }
}

@Composable fun Empty(msg: String) {
    Column(Modifier.fillMaxWidth().padding(36.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        IconBadge("✨", MaterialTheme.colorScheme.primary, 64.dp)
        Spacer(Modifier.height(12.dp))
        Text(msg, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
    }
}

@Composable fun Note(text: String) {
    Text(text, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(horizontal = 4.dp, vertical = 4.dp))
}

@Composable fun SortBar(vm: VM) {
    Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Pill(tr("সাজান: ", "Sort: ") + when (vm.sort) { "name" -> tr("নাম", "Name"); "size" -> tr("আকার", "Size"); else -> tr("তারিখ", "Date") }) {
            vm.sort = when (vm.sort) { "name" -> "size"; "size" -> "date"; else -> "name" }
        }
        Spacer(Modifier.width(6.dp))
        Pill(if (vm.asc) tr("ছোট→বড় ↑", "Asc ↑") else tr("বড়→ছোট ↓", "Desc ↓")) { vm.asc = !vm.asc }
        Spacer(Modifier.width(6.dp))
        Pill(if (vm.grid) "☰" else "▦") { vm.grid = !vm.grid; vm.setPref("grid", vm.grid) }
    }
}

@Composable fun chipColors() = FilterChipDefaults.filterChipColors(
    selectedContainerColor = MaterialTheme.colorScheme.primary.copy(alpha = .20f),
    selectedLabelColor = MaterialTheme.colorScheme.primary
)

@Composable fun CatChips(sel: Cat?, onSel: (Cat?) -> Unit) {
    val cc = chipColors()
    LazyRow(contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        item { FilterChip(sel == null, { onSel(null) }, { Text(tr("সব", "All")) }, shape = RoundedCornerShape(50), colors = cc) }
        items(Cat.values().toList()) { c -> FilterChip(sel == c, { onSel(c) }, { Text(c.icon + " " + c.label) }, shape = RoundedCornerShape(50), colors = cc) }
    }
}

@Composable fun ListScreen(vm: VM, fl: List<File>) {
    if (fl.isEmpty()) Empty(tr("কিছু পাওয়া যায়নি", "Nothing found"))
    else LazyColumn(contentPadding = PaddingValues(12.dp)) { items(fl, key = { it.path }) { FileItem(vm, it, it.parent) } }
}

// ---------- screens ----------
private class Tile(val s: String, val i: String, val l: String, val c: Color)

@Composable fun HomeScreen(vm: VM) {
    val st = remember(vm.tick) { vm.storage() }; val total = st.first; val free = st.second
    val p = if (total > 0) (total - free).toFloat() / total else 0f
    val seg = remember(vm.all) { Cat.values().map { c -> c to vm.all.filter { catOf(it) == c }.sumOf { it.length() }.coerceAtLeast(1L) } }
    val tiles = listOf(
        Tile("cats", "🗂️", tr("ক্যাটাগরি", "Categories"), Color(0xFF3B82F6)), Tile("storage", "📊", tr("স্টোরেজ", "Storage"), Color(0xFF8B5CF6)), Tile("fav", "⭐", tr("ফেভারিট", "Favorites"), Color(0xFFF2B632)),
        Tile("bin", "♻️", tr("রিসাইকেল বিন", "Recycle bin"), Color(0xFF22C55E)), Tile("dups", "👯", tr("ডুপ্লিকেট", "Duplicates"), Color(0xFFFF5C8A)), Tile("priv", "🔐", tr("প্রাইভেট", "Private"), Color(0xFF6366F1)),
        Tile("sus", "⚠️", tr("সন্দেহজনক", "Suspicious"), Color(0xFFFF9F43)), Tile("quar", "🧪", tr("কোয়ারেন্টাইন", "Quarantine"), Color(0xFF14B8A6)), Tile("cloud", "☁️", tr("ক্লাউড", "Cloud"), Color(0xFF22D3EE)))
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(32.dp)).background(heroBrush())) {
                Canvas(Modifier.matchParentSize()) {
                    drawCircle(Color.White.copy(alpha = .09f), size.minDimension * 0.65f, Offset(size.width, 0f))
                    drawCircle(Color.White.copy(alpha = .06f), size.minDimension * 0.45f, Offset(0f, size.height))
                }
                Column(Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Donut(p, 104.dp, num("${(p * 100).toInt()}%"), onHero = true)
                        Column(Modifier.padding(start = 14.dp)) {
                            Text(tr("ফোনের স্টোরেজ", "Phone storage"), color = Color.White.copy(alpha = .85f), fontSize = 13.sp)
                            Text(sizeStr(total - free), color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 28.sp)
                            Text(tr("মোট ", "of ") + sizeStr(total) + " · " + tr("খালি ", "free ") + sizeStr(free), color = Color.White.copy(alpha = .85f), fontSize = 13.sp)
                        }
                    }
                    Spacer(Modifier.height(16.dp))
                    Row(Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)).background(Color.White.copy(alpha = .15f)), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                        seg.forEach { (c, v) -> Box(Modifier.weight(v.toFloat()).fillMaxHeight().background(catColor(c))) }
                    }
                    Spacer(Modifier.height(12.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(Cat.IMG, Cat.VID, Cat.AUD, Cat.DOC).forEach { c ->
                            Column(Modifier.weight(1f).clip(RoundedCornerShape(16.dp)).background(Color.White.copy(alpha = .15f)).padding(vertical = 10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(num("${vm.vm_count(c)}"), fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Color.White)
                                Text(c.icon + " " + c.label, fontSize = 11.sp, color = Color.White.copy(alpha = .9f), maxLines = 1)
                            }
                        }
                    }
                    if (vm.scanning) {
                        Spacer(Modifier.height(12.dp))
                        LinearProgressIndicator(Modifier.fillMaxWidth().clip(RoundedCornerShape(4.dp)), color = Color.White, trackColor = Color.White.copy(alpha = .25f))
                        Text(tr("স্ক্যান চলছে…", "Scanning…"), fontSize = 12.sp, color = Color.White.copy(alpha = .9f), modifier = Modifier.padding(top = 4.dp))
                    }
                }
            }
        }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                tiles.chunked(3).forEach { r ->
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        r.forEach { t ->
                            Column(Modifier.weight(1f).panel(RoundedCornerShape(20.dp)).clickable { vm.go(t.s) }.padding(vertical = 14.dp, horizontal = 4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                IconBadge(t.i, t.c, 48.dp)
                                Spacer(Modifier.height(8.dp))
                                Text(t.l, fontSize = 12.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        }
                    }
                }
            }
        }
        val fd = vm.favs.map { File(it) }.filter { it.isDirectory }
        if (fd.isNotEmpty()) {
            item { SectionTitle(tr("গুরুত্বপূর্ণ ফোল্ডার", "Important folders")) }
            item { Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) { fd.forEach { d -> Pill("📁 " + d.name) { vm.tap(d) } } } }
        }
        item { SectionTitle(tr("সাম্প্রতিক ফাইল", "Recent files")) }
        items(vm.all.sortedByDescending { it.lastModified() }.take(6), key = { it.path }) { FileItem(vm, it) }
    }
}

private fun VM.vm_count(c: Cat): Int = all.count { catOf(it) == c }

@Composable fun FilesScreen(vm: VM) {
    val fl = remember(vm.cwd, vm.tick, vm.sort, vm.asc, vm.flt) { vm.list() }
    val parts = generateSequence(vm.cwd) { if (it == P.root) null else it.parentFile }.takeWhile { it.path.startsWith(P.root.path) }.toList().reversed()
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            parts.forEachIndexed { i, d ->
                TextButton(onClick = { vm.cwd = d }) { Text(if (i == 0) tr("হোম", "Home") else d.name, fontWeight = if (i == parts.size - 1) FontWeight.Bold else FontWeight.Normal) }
                if (i < parts.size - 1) Text("›", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Pill("📁＋ " + tr("নতুন", "New"), filled = true) { vm.dlg = Dlg.Ask(tr("নতুন ফোল্ডার", "New folder"), "", false) { vm.mkdir(it) } }
            Spacer(Modifier.width(6.dp))
            Pill(if (vm.selMode) tr("বাতিল", "Cancel") else "☑ " + tr("নির্বাচন", "Select")) { if (vm.selMode) vm.clearSel() else vm.selMode = true }
            Spacer(Modifier.width(6.dp))
            Pill("🔄") { vm.refresh() }
        }
        SortBar(vm)
        CatChips(vm.flt) { vm.flt = it }
        Spacer(Modifier.height(4.dp))
        if (fl.isEmpty()) Empty(tr("ফোল্ডারটি খালি", "This folder is empty"))
        else if (vm.grid) LazyVerticalGrid(GridCells.Fixed(3), contentPadding = PaddingValues(8.dp)) { items(fl, key = { it.path }) { GridCell(vm, it) } }
        else LazyColumn(contentPadding = PaddingValues(12.dp)) { items(fl, key = { it.path }) { FileItem(vm, it) } }
    }
}

@Composable fun CatsScreen(vm: VM) {
    var open by remember { mutableStateOf<Cat?>(null) }
    if (open == null) {
        LazyColumn(contentPadding = PaddingValues(12.dp)) {
            items(Cat.values().toList()) { c ->
                val l = vm.all.filter { catOf(it) == c }
                ItemRow(c.icon, c.label, num("${l.size}") + tr("টি ফাইল · ", " files · ") + sizeStr(l.sumOf { it.length() }), catColor(c), { open = c })
            }
        }
    } else {
        val c = open!!
        val l = vm.all.filter { catOf(it) == c }.let { a ->
            val s = when (vm.sort) { "size" -> a.sortedBy { it.length() }; "date" -> a.sortedBy { it.lastModified() }; else -> a.sortedBy { it.name.lowercase() } }
            if (vm.asc) s else s.reversed()
        }
        BackHandler { open = null }
        Column {
            Row(Modifier.padding(horizontal = 12.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) { Pill("← " + tr("সব ক্যাটাগরি", "All categories")) { open = null } }
            SortBar(vm)
            ListScreen(vm, l)
        }
    }
}

@Composable fun SearchScreen(vm: VM) {
    var q by remember { mutableStateOf("") }; var ex by remember { mutableStateOf("") }
    var cat by remember { mutableStateOf<Cat?>(null) }; var here by remember { mutableStateOf(false) }
    val res = remember(q, ex, cat, here, vm.all) {
        vm.all.filter { (q.isBlank() || it.name.contains(q, true)) && (cat == null || catOf(it) == cat) && (ex.isBlank() || it.extension.equals(ex.trim('.', ' '), true)) && (!here || it.startsWith(vm.cwd)) }.take(300)
    }
    val cc = chipColors()
    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        item { OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth(), singleLine = true, shape = RoundedCornerShape(18.dp), leadingIcon = { Text("🔍") }, label = { Text(tr("ফাইলের নাম লিখুন", "File name")) }) }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(ex, { ex = it }, Modifier.weight(1f), singleLine = true, shape = RoundedCornerShape(18.dp), label = { Text(tr("এক্সটেনশন (pdf)", "Extension (pdf)")) })
                Spacer(Modifier.width(8.dp))
                FilterChip(here, { here = !here }, { Text(tr("এই ফোল্ডারে", "This folder")) }, shape = RoundedCornerShape(50), colors = cc)
            }
        }
        item { Box(Modifier.offset(x = (-12).dp).fillMaxWidth()) { CatChips(cat) { cat = it } } }
        item { Note(if (vm.scanning) tr("স্ক্যান চলছে…", "Scanning…") else num("${res.size}") + tr("টি ফলাফল", " results")) }
        items(res, key = { it.path }) { FileItem(vm, it, it.parent) }
    }
}

@Composable fun ToolsScreen(vm: VM) {
    val cs = MaterialTheme.colorScheme
    LazyColumn(contentPadding = PaddingValues(12.dp)) {
        item { ItemRow("🗜️", tr("ZIP তৈরি", "Create ZIP"), tr("ফাইল নির্বাচন করে ZIP বানান", "Select files, then ZIP"), Color(0xFFF2B632), { vm.nav("files"); vm.selMode = true; vm.toast(tr("ফাইল বেছে নিয়ে ZIP চাপুন", "Select files then tap ZIP")) }) }
        item { ItemRow("📦", tr("ZIP / আর্কাইভ", "ZIP / archives"), tr("তালিকা দেখা ও Extract", "List and extract"), Color(0xFFFF9F43), { vm.go("zips") }) }
        item { ItemRow("🤖", "APK", tr("APK শনাক্ত ও তথ্য", "Find APKs and see info"), Color(0xFF22C55E), { vm.go("apk") }) }
        item { ItemRow("📑", tr("CSV রিপোর্ট", "CSV report"), tr("সব ফাইলের তালিকা Export", "Export all files"), Color(0xFF3B82F6), { vm.csv(vm.all, "file-report.csv") }) }
        item { ItemRow("⭐", tr("ফেভারিট তালিকা Export", "Export favorites"), "CSV", Color(0xFFF2B632), { vm.csv(vm.favs.map { File(it) }.filter { it.isFile }, "favorites.csv") }) }
        item { ItemRow("📊", tr("বড় ফাইল খুঁজুন", "Find large files"), tr("স্টোরেজ বিশ্লেষণে দেখুন", "See in storage analysis"), Color(0xFF8B5CF6), { vm.go("storage") }) }
        item { ItemRow("📄", tr("ডকুমেন্ট (PDF, TXT…)", "Documents (PDF, TXT…)"), tr("ক্যাটাগরিতে দেখুন", "Browse by category"), cs.primary, { vm.go("cats") }) }
    }
}

@Composable fun StorageScreen(vm: VM) {
    val st = remember(vm.tick) { vm.storage() }; val used = st.first - st.second
    val by = vm.all.groupBy { catOf(it) }.mapValues { e -> e.value.sumOf { it.length() } }
    val sum = (by.values.sum()).coerceAtLeast(1L)
    LazyColumn(contentPadding = PaddingValues(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(32.dp)).background(heroBrush())) {
                Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Donut(if (st.first > 0) used.toFloat() / st.first else 0f, 108.dp, num("${if (st.first > 0) (used * 100 / st.first) else 0}%"), onHero = true)
                    Column(Modifier.padding(start = 16.dp)) {
                        Text(tr("মোট: ", "Total: ") + sizeStr(st.first), color = Color.White, fontWeight = FontWeight.Bold)
                        Text(tr("ব্যবহৃত: ", "Used: ") + sizeStr(used), color = Color.White.copy(alpha = .9f))
                        Text(tr("খালি: ", "Free: ") + sizeStr(st.second), color = Color.White.copy(alpha = .9f))
                    }
                }
            }
        }
        items(Cat.values().toList()) { c ->
            val v = by[c] ?: 0L; val cc = catColor(c)
            Column(Modifier.fillMaxWidth().panel(RoundedCornerShape(18.dp)).padding(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconBadge(c.icon, cc, 34.dp)
                    Text(c.label, Modifier.weight(1f).padding(start = 10.dp), fontWeight = FontWeight.SemiBold)
                    Text(sizeStr(v) + " · " + num("${v * 100 / sum}") + "%", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Spacer(Modifier.height(8.dp))
                Box(Modifier.fillMaxWidth().height(10.dp).clip(RoundedCornerShape(5.dp)).background(MaterialTheme.colorScheme.surfaceVariant)) {
                    Box(Modifier.fillMaxWidth((v.toFloat() / sum).coerceIn(0f, 1f)).fillMaxHeight().clip(RoundedCornerShape(5.dp)).background(Brush.horizontalGradient(listOf(cc, cc.copy(alpha = .6f)))))
                }
            }
        }
        item { SectionTitle(tr("সবচেয়ে বড় ফাইল", "Largest files")) }
        items(vm.all.sortedByDescending { it.length() }.take(15), key = { it.path }) { FileItem(vm, it, sizeStr(it.length()) + if (it.length() >= 50_000_000) tr(" · বড় ফাইল", " · large") else "") }
    }
}

@Composable fun BinScreen(vm: VM) {
    val l = remember(vm.tick) { vm.binFiles() }
    LazyColumn(contentPadding = PaddingValues(12.dp)) {
        item { if (l.isNotEmpty()) Pill("🧹 " + tr("সব পরিষ্কার করুন", "Empty bin"), filled = true) { vm.dlg = Dlg.Sure(tr("বিনের সব ফাইল স্থায়ীভাবে মুছে যাবে।", "Everything in the bin will be deleted permanently.")) { vm.wipeBin() } } }
        if (l.isEmpty()) item { Empty(tr("রিসাইকেল বিন খালি", "Recycle bin is empty")) }
        items(l, key = { it.path }) { f ->
            ItemRow(if (f.isDirectory) "📁" else catOf(f).icon, f.name.substringAfter("_"), sizeStr(if (f.isFile) f.length() else 0) + " · " + dateStr(vm.delTime(f)), if (f.isDirectory) Color(0xFFFF9F43) else catColor(catOf(f))) {
                TextButton(onClick = { vm.restore(f) }) { Text("↩️") }
                TextButton(onClick = { vm.dlg = Dlg.Sure(tr("স্থায়ীভাবে মুছে ফেলবেন? আর ফেরানো যাবে না।", "Delete permanently? This cannot be undone.")) { vm.purge(listOf(f)) } }) { Text("❌") }
            }
        }
    }
}

@Composable fun FavScreen(vm: VM) {
    val l = vm.favs.map { File(it) }.filter { it.exists() }
    if (l.isEmpty()) Empty(tr("কোনো ফেভারিট নেই। ফাইল চেপে ⭐ দিন।", "No favorites yet. Open a file and tap ⭐."))
    else ListScreen(vm, l)
}

@Composable fun DupsScreen(vm: VM) {
    var g by remember { mutableStateOf<List<List<File>>?>(null) }
    LaunchedEffect(vm.all) { g = null; g = vm.dups() }
    val gs = g
    if (gs == null) Empty(tr("ডুপ্লিকেট খোঁজা হচ্ছে…", "Searching duplicates…"))
    else if (gs.isEmpty()) Empty("✅ " + tr("ডুপ্লিকেট পাওয়া যায়নি", "No duplicates found"))
    else LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { Note(tr("নাম নয়, ফাইলের আসল বিষয়বস্তু (SHA-256) মিলিয়ে ধরা হয়েছে। মোছার আগে নিশ্চিত করতে বলা হবে।", "Matched by real content (SHA-256), not name. You confirm before deleting.")) }
        items(gs) { grp ->
            Column(Modifier.fillMaxWidth().panel(RoundedCornerShape(22.dp)).padding(10.dp)) {
                Text(num("${grp.size}") + tr("টি একই ফাইল · ", " identical · ") + sizeStr(grp[0].length()), fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 4.dp, bottom = 4.dp))
                grp.forEachIndexed { i, f ->
                    FileItem(vm, f, f.parent) {
                        if (i > 0) TextButton(onClick = { vm.dlg = Dlg.Sure(tr("এই কপিটি রিসাইকেল বিনে যাবে।", "This copy goes to the recycle bin.")) { vm.trash(listOf(f)) } }) { Text("🗑️") }
                        else Text(tr("রাখুন", "Keep"), fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable fun SusScreen(vm: VM) {
    val l = remember(vm.all) { vm.suspicious() }
    LazyColumn(contentPadding = PaddingValues(12.dp)) {
        item { Note(tr("ফাইলের নাম ও এক্সটেনশন দেখে সম্ভাব্য ঝুঁকি চিহ্নিত করা হয়। এটি অ্যান্টিভাইরাস নয়।", "Flags risky names and extensions. This is not an antivirus.")) }
        if (l.isEmpty()) item { Empty("✅ " + tr("সন্দেহজনক ফাইল পাওয়া যায়নি", "Nothing suspicious found")) }
        else item { Box(Modifier.padding(vertical = 6.dp)) { Pill("🧪 " + tr("সব কোয়ারেন্টাইনে কপি করুন", "Copy all to quarantine"), filled = true) { vm.quarantine(l) } } }
        items(l, key = { it.path }) { f -> FileItem(vm, f, why(f).joinToString(", ")) { TextButton(onClick = { vm.quarantine(listOf(f)) }) { Text("🧪") } } }
    }
}

@Composable fun QuarScreen(vm: VM) {
    val l = remember(vm.tick) { vm.quarFiles() }
    LazyColumn(contentPadding = PaddingValues(12.dp)) {
        item { Note(tr("এখানকার ফাইল আপনার অনুমতি ছাড়া মোছা হয় না। মূল ফাইলও থেকে যায়।", "Nothing here is deleted without your permission. Originals are kept.")) }
        if (l.isEmpty()) item { Empty(tr("কোয়ারেন্টাইন খালি", "Quarantine is empty")) }
        items(l, key = { it.path }) { f ->
            ItemRow("🧪", f.name, tr("মূল অবস্থান: ", "Original: ") + vm.origOf("quar", f), Color(0xFF14B8A6)) {
                TextButton(onClick = { vm.quarRestore(f) }) { Text("↩️") }
                TextButton(onClick = { vm.dlg = Dlg.Sure(tr("কোয়ারেন্টাইন থেকে স্থায়ীভাবে মুছবেন?", "Delete from quarantine permanently?")) { vm.quarDelete(f) } }) { Text("🗑️") }
            }
        }
    }
}

@Composable fun PrivScreen(vm: VM, act: MainActivity) {
    if (!vm.privOK) {
        Column(Modifier.fillMaxSize().padding(24.dp), Arrangement.Center, Alignment.CenterHorizontally) {
            HeroIcon("🔐")
            Spacer(Modifier.height(18.dp))
            Text(if (vm.pin.isEmpty()) tr("প্রাইভেট ফোল্ডার ব্যবহারে আগে সেটিংসে পিন সেট করুন।", "Set a PIN in Settings to use the private folder.") else tr("প্রাইভেট ফোল্ডার দেখতে পিন লাগবে।", "A PIN is required."), textAlign = TextAlign.Center)
            Spacer(Modifier.height(18.dp))
            if (vm.pin.isNotEmpty()) {
                GradientButton(tr("পিন দিয়ে খুলুন", "Unlock with PIN")) { vm.dlg = Dlg.Ask(tr("পিন দিন", "Enter PIN"), "", true) { if (sha(it) == vm.pin) vm.privOK = true else vm.toast(tr("ভুল পিন", "Wrong PIN")) } }
                if (vm.bio) { Spacer(Modifier.height(10.dp)); Pill("👆 " + tr("ফিঙ্গারপ্রিন্ট", "Fingerprint")) { act.biometric { vm.privOK = true } } }
            } else GradientButton(tr("সেটিংসে যান", "Open settings")) { vm.nav("settings") }
        }
        return
    }
    val l = remember(vm.tick, vm.privOK) { vm.privFiles() }
    LazyColumn(contentPadding = PaddingValues(12.dp)) {
        item { Pill("🔒 " + tr("লক করুন", "Lock")) { vm.privOK = false } }
        if (l.isEmpty()) item { Empty(tr("খালি। ফাইলের মেনু থেকে “প্রাইভেটে নিন” চাপুন।", "Empty. Use “Move to private” from a file's menu.")) }
        items(l, key = { it.path }) { f ->
            ItemRow(catOf(f).icon, f.name, sizeStr(f.length()), catColor(catOf(f))) {
                val c = LocalContext.current
                TextButton(onClick = { openFile(c, f) }) { Text("👁️") }
                TextButton(onClick = { vm.fromPrivate(f) }) { Text("↩️") }
            }
        }
    }
}

@Composable fun CloudScreen(vm: VM) {
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { vm.importUris(it) }
    LazyColumn(contentPadding = PaddingValues(12.dp)) {
        item { Box(Modifier.fillMaxWidth().padding(vertical = 3.dp).panel(RoundedCornerShape(18.dp))) { Text(tr("Google Drive বা Dropbox-এ সরাসরি লগইন করতে তাদের API Key (OAuth Client ID) লাগে। তাই ফোনের ফাইল পিকার ও শেয়ার মেনু ব্যবহার হয়; দুটোতেই Drive ও Dropbox থাকে।", "Direct Drive/Dropbox sign-in needs your own OAuth client ID. This uses the system file picker and share sheet, which include Drive and Dropbox."), Modifier.padding(14.dp), fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) } }
        item { ItemRow("⬇️", tr("ক্লাউড থেকে ফাইল আনুন", "Download from cloud"), tr("বর্তমান ফোল্ডারে কপি হবে", "Saved into the current folder"), Color(0xFF22D3EE), { pick.launch(arrayOf("*/*")) }) }
        item { ItemRow("⬆️", tr("ক্লাউডে আপলোড করুন", "Upload to cloud"), tr("ফাইল বেছে শেয়ার → Drive/Dropbox", "Select files → Share → Drive/Dropbox"), Color(0xFF8B5CF6), { vm.nav("files"); vm.selMode = true; vm.toast(tr("ফাইল বেছে 📤 শেয়ার চাপুন", "Select files, tap Share")) }) }
    }
}

@Composable fun SettingsScreen(vm: VM, act: MainActivity) {
    @Composable fun Sw(l: String, v: Boolean, f: (Boolean) -> Unit) { Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) { Text(l, Modifier.weight(1f)); Switch(v, f) } }
    val cc = chipColors()
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        SectionTitle(tr("থিম ও ভিউ", "Look & feel"))
        Column(Modifier.fillMaxWidth().panel(RoundedCornerShape(22.dp)).padding(horizontal = 16.dp, vertical = 8.dp)) {
            Sw("🌙 " + tr("ডার্ক মোড", "Dark mode"), vm.dark) { vm.dark = it; vm.setPref("dark", it) }
            Sw("▦ " + tr("গ্রিড ভিউ", "Grid view"), vm.grid) { vm.grid = it; vm.setPref("grid", it) }
            Sw("📏 " + tr("ফাইলের আকার দেখান", "Show file size"), vm.showSize) { vm.showSize = it; vm.setPref("size", it) }
            Sw("📅 " + tr("তারিখ দেখান", "Show date"), vm.showDate) { vm.showDate = it; vm.setPref("date", it) }
            Sw("🔔 " + tr("নোটিফিকেশন (বার্তা)", "Notifications (toasts)"), vm.notif) { vm.notif = it; vm.setPref("notif", it) }
        }
        SectionTitle(tr("ভাষা", "Language"))
        Row(Modifier.fillMaxWidth().panel(RoundedCornerShape(22.dp)).padding(14.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(LANG == "bn", { vm.setLang("bn") }, { Text("বাংলা") }, shape = RoundedCornerShape(50), colors = cc)
            FilterChip(LANG == "en", { vm.setLang("en") }, { Text("English") }, shape = RoundedCornerShape(50), colors = cc)
        }
        SectionTitle(tr("নিরাপত্তা", "Security"))
        Column(Modifier.fillMaxWidth().panel(RoundedCornerShape(22.dp)).padding(14.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Pill(if (vm.pin.isEmpty()) "🔐 " + tr("পিন সেট করুন", "Set PIN") else "🔐 " + tr("পিন বদলান", "Change PIN"), filled = true) {
                    vm.dlg = Dlg.Ask(tr("নতুন পিন (৪+ সংখ্যা)", "New PIN (4+ digits)"), "", true) { if (it.length >= 4) { vm.setPin(it); vm.toast(tr("পিন সেট হয়েছে", "PIN set")) } else vm.toast(tr("অন্তত ৪ সংখ্যা", "At least 4 digits")) }
                }
                if (vm.pin.isNotEmpty()) Pill(tr("পিন বন্ধ", "Remove PIN")) { vm.setPin(""); vm.bio = false; vm.setPref("bio", false) }
            }
            if (vm.pin.isNotEmpty() && act.bioAvailable()) { Spacer(Modifier.height(6.dp)); Sw("👆 " + tr("ফিঙ্গারপ্রিন্ট লক", "Fingerprint lock"), vm.bio) { vm.bio = it; vm.setPref("bio", it) } }
            else if (vm.pin.isNotEmpty()) Note(tr("এই ডিভাইসে ফিঙ্গারপ্রিন্ট সমর্থিত নয় বা সেট করা নেই।", "Fingerprint not available on this device."))
        }
        Note(tr("শর্টকাট: অ্যাপ আইকন চেপে ধরে সার্চ, স্টোরেজ ও রিসাইকেল বিনে যান।", "Shortcuts: long-press the app icon for Search, Storage and Recycle bin."))
    }
}

// ---------- dialogs ----------
@Composable fun DialogHost(vm: VM) {
    val d = vm.dlg ?: return
    val close = { vm.dlg = null }
    when (d) {
        is Dlg.Info -> InfoDlg(vm, d.f)
        is Dlg.Ask -> {
            var t by remember { mutableStateOf(d.def) }
            AlertDialog(onDismissRequest = close, title = { Text(d.title) },
                text = { OutlinedTextField(t, { t = it }, singleLine = true, shape = RoundedCornerShape(16.dp), visualTransformation = if (d.pw) PasswordVisualTransformation() else VisualTransformation.None,
                    keyboardOptions = KeyboardOptions(keyboardType = if (d.pw) KeyboardType.NumberPassword else KeyboardType.Text)) },
                confirmButton = { TextButton(onClick = { close(); d.ok(t) }) { Text(tr("ঠিক আছে", "OK"), fontWeight = FontWeight.Bold) } },
                dismissButton = { TextButton(onClick = close) { Text(tr("বাতিল", "Cancel")) } })
        }
        is Dlg.Sure -> AlertDialog(onDismissRequest = close, title = { Text(tr("নিশ্চিত করুন", "Confirm")) }, text = { Text(d.msg) },
            confirmButton = { TextButton(onClick = { close(); d.ok() }) { Text(tr("হ্যাঁ", "Yes"), fontWeight = FontWeight.Bold) } },
            dismissButton = { TextButton(onClick = close) { Text(tr("না", "No")) } })
        is Dlg.Lines -> AlertDialog(onDismissRequest = close, title = { Text(d.title) },
            text = { Column(Modifier.verticalScroll(rememberScrollState())) { d.lines.forEach { Text(it, fontSize = 13.sp) } } },
            confirmButton = { TextButton(onClick = close) { Text(tr("বন্ধ", "Close")) } })
        is Dlg.Pick -> {
            var cur by remember { mutableStateOf(vm.cwd) }
            val subs = remember(cur) { cur.listFiles()?.filter { it.isDirectory && !it.name.startsWith(".") }?.sortedBy { it.name.lowercase() } ?: emptyList() }
            AlertDialog(onDismissRequest = close, title = { Text(tr("ফোল্ডার বেছে নিন", "Choose folder")) },
                text = {
                    Column {
                        Text(cur.path, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        if (cur != P.root) TextButton(onClick = { cur = cur.parentFile ?: P.root }) { Text("⬆️ ..") }
                        LazyColumn(Modifier.heightIn(max = 280.dp)) { items(subs) { s -> TextButton(onClick = { cur = s }) { Text("📁 " + s.name) } } }
                    }
                },
                confirmButton = { TextButton(onClick = { close(); d.ok(cur) }) { Text(tr("এখানে", "Here"), fontWeight = FontWeight.Bold) } },
                dismissButton = { TextButton(onClick = close) { Text(tr("বাতিল", "Cancel")) } })
        }
    }
}

@Composable fun InfoDlg(vm: VM, f: File) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val close = { vm.dlg = null }
    val w = why(f)
    val acts = ArrayList<Pair<String, () -> Unit>>()
    fun add(l: String, a: () -> Unit) { acts.add(l to a) }
    if (f.isFile) add("📂 " + tr("খুলুন", "Open")) { close(); openFile(ctx, f) }
    add(if (f.absolutePath in vm.favs) "★ " + tr("ফেভারিট সরান", "Unfavorite") else "☆ " + tr("ফেভারিট", "Favorite")) { vm.toggleFav(f); close() }
    add("✏️ " + tr("নাম পরিবর্তন", "Rename")) { vm.dlg = Dlg.Ask(tr("নতুন নাম", "New name"), f.name, false) { vm.rename(f, it) } }
    add("📋 " + tr("কপি", "Copy")) { vm.dlg = Dlg.Pick { vm.copy(listOf(f), it) } }
    add("📂 " + tr("সরান", "Move")) { vm.dlg = Dlg.Pick { vm.move(listOf(f), it) } }
    if (f.isFile) add("📤 " + tr("শেয়ার", "Share")) { close(); shareFiles(ctx, listOf(f)) }
    add("🗜️ " + tr("ZIP করুন", "Zip")) { close(); vm.zip(listOf(f)) }
    if (f.extension.equals("zip", true)) {
        add("📦 " + tr("ভেতরের তালিকা", "List contents")) { vm.dlg = Dlg.Lines(f.name, vm.zipList(f)) }
        add("📂 Extract") { close(); vm.unzip(f) }
    }
    if (f.extension.equals("apk", true)) add("🤖 " + tr("APK তথ্য", "APK info")) { vm.dlg = Dlg.Lines("APK", vm.apkInfo(f)) }
    if (w.isNotEmpty()) add("🧪 " + tr("কোয়ারেন্টাইনে কপি", "Quarantine copy")) { close(); vm.quarantine(listOf(f)) }
    if (f.isFile) add("🔐 " + tr("প্রাইভেটে নিন", "Move to private")) { close(); if (vm.pin.isEmpty()) vm.toast(tr("আগে সেটিংসে পিন সেট করুন", "Set a PIN in Settings first")) else vm.toPrivate(f) }
    add("🗑️ " + tr("মুছুন", "Delete")) { vm.dlg = Dlg.Sure(tr("রিসাইকেল বিনে পাঠানো হবে।", "It will go to the recycle bin.")) { vm.trash(listOf(f)) } }
    AlertDialog(onDismissRequest = close, title = { Text(f.name, maxLines = 2, overflow = TextOverflow.Ellipsis) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(cs.surfaceVariant).padding(12.dp)) {
                    Text(tr("অবস্থান: ", "Path: ") + (f.parent ?: ""), fontSize = 12.sp)
                    if (f.isFile) Text(tr("ধরন: ", "Type: ") + catOf(f).label + " (." + f.extension + ")", fontSize = 12.sp)
                    Text(tr("আকার: ", "Size: ") + sizeStr(if (f.isFile) f.length() else f.walkTopDown().filter { it.isFile }.sumOf { it.length() }), fontSize = 12.sp)
                    Text(tr("পরিবর্তন: ", "Modified: ") + dateStr(f.lastModified()), fontSize = 12.sp)
                    if (w.isNotEmpty()) Text("⚠️ " + w.joinToString(", "), color = cs.error, fontSize = 12.sp)
                }
                Spacer(Modifier.height(10.dp))
                acts.chunked(2).forEach { r ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        r.forEach { (l, a) ->
                            Box(Modifier.weight(1f).panel(RoundedCornerShape(14.dp)).clickable(onClick = a).padding(horizontal = 8.dp, vertical = 11.dp), contentAlignment = Alignment.Center) {
                                Text(l, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        }
                        if (r.size == 1) Spacer(Modifier.weight(1f))
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = close) { Text(tr("বন্ধ", "Close")) } })
}
