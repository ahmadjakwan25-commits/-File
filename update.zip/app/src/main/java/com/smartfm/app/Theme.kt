package com.smartfm.app

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/* ------------------------------------------------------------------
   Smart File Manager — design system
   Light  : ice-white canvas, electric indigo + cyan accents
   Dark   : deep midnight navy, neon cyan + violet "digital" glow
------------------------------------------------------------------- */

val LocalDark = staticCompositionLocalOf { false }

val LightBg = Color(0xFFF4F7FE)
val DarkBg = Color(0xFF0A0E1F)

private val LightScheme = lightColorScheme(
    primary = Color(0xFF3B5BFF), onPrimary = Color.White,
    primaryContainer = Color(0xFFDCE4FF), onPrimaryContainer = Color(0xFF14238A),
    secondary = Color(0xFF00A9C9), onSecondary = Color.White,
    secondaryContainer = Color(0xFFCFF4FC), onSecondaryContainer = Color(0xFF00424F),
    tertiary = Color(0xFF7A4DFF), onTertiary = Color.White,
    background = LightBg, onBackground = Color(0xFF0F172A),
    surface = Color.White, onSurface = Color(0xFF0F172A),
    surfaceVariant = Color(0xFFE6ECFA), onSurfaceVariant = Color(0xFF5B6785),
    surfaceContainer = Color(0xFFFFFFFF), surfaceContainerHigh = Color(0xFFFFFFFF),
    outline = Color(0xFFD3DBF1), outlineVariant = Color(0xFFE3E9F8),
    error = Color(0xFFE5383B)
)

private val DarkScheme = darkColorScheme(
    primary = Color(0xFF7C95FF), onPrimary = Color(0xFF0A1052),
    primaryContainer = Color(0xFF26318F), onPrimaryContainer = Color(0xFFDCE4FF),
    secondary = Color(0xFF22E3FF), onSecondary = Color(0xFF00313B),
    secondaryContainer = Color(0xFF0B4A58), onSecondaryContainer = Color(0xFFB8F3FF),
    tertiary = Color(0xFFB596FF), onTertiary = Color(0xFF260B6B),
    background = DarkBg, onBackground = Color(0xFFE8ECFF),
    surface = Color(0xFF121835), onSurface = Color(0xFFE8ECFF),
    surfaceVariant = Color(0xFF1C2349), onSurfaceVariant = Color(0xFF9AA5CE),
    surfaceContainer = Color(0xFF0F1530), surfaceContainerHigh = Color(0xFF171E42),
    outline = Color(0xFF2E3869), outlineVariant = Color(0xFF232C58),
    error = Color(0xFFFF6B7A)
)

private val AppShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp), small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(16.dp), large = RoundedCornerShape(22.dp), extraLarge = RoundedCornerShape(28.dp)
)

private val AppTypography = Typography().let { b ->
    Typography(
        titleLarge = b.titleLarge.copy(fontWeight = FontWeight.Bold),
        titleMedium = b.titleMedium.copy(fontWeight = FontWeight.SemiBold)
    )
}

@Composable fun AppTheme(dark: Boolean, content: @Composable () -> Unit) {
    CompositionLocalProvider(LocalDark provides dark) {
        MaterialTheme(colorScheme = if (dark) DarkScheme else LightScheme, shapes = AppShapes, typography = AppTypography, content = content)
    }
}

/* ---------- colours & brushes ---------- */

fun catColor(c: Cat): Color = when (c) {
    Cat.IMG -> Color(0xFFFF5C8A)
    Cat.VID -> Color(0xFF8B5CF6)
    Cat.AUD -> Color(0xFFFF9F43)
    Cat.DOC -> Color(0xFF3B82F6)
    Cat.ARC -> Color(0xFFF2B632)
    Cat.APK -> Color(0xFF22C55E)
    Cat.OTH -> Color(0xFF64748B)
}

val FolderBrush = Brush.linearGradient(listOf(Color(0xFFFFC857), Color(0xFFFF9F43)))

fun accentBrush(): Brush = Brush.horizontalGradient(listOf(Color(0xFF4F6BFF), Color(0xFF8A5CFF)))

@Composable fun heroBrush(): Brush =
    if (LocalDark.current) Brush.linearGradient(listOf(Color(0xFF2A3BD8), Color(0xFF6B3DEB), Color(0xFF0E8FB5)))
    else Brush.linearGradient(listOf(Color(0xFF3556FF), Color(0xFF7A4DFF), Color(0xFF12B8D8)))

/* ---------- background: soft glow + digital dot grid ---------- */

@Composable fun AppBackground(content: @Composable BoxScope.() -> Unit) {
    val dark = LocalDark.current
    val bg = MaterialTheme.colorScheme.background
    val dot = if (dark) Color.White.copy(alpha = .05f) else Color(0xFF3B5BFF).copy(alpha = .07f)
    val glow1 = if (dark) Color(0xFF3B5BFF).copy(alpha = .30f) else Color(0xFF3B5BFF).copy(alpha = .12f)
    val glow2 = if (dark) Color(0xFF22E3FF).copy(alpha = .13f) else Color(0xFF00B8D9).copy(alpha = .10f)
    Box(Modifier.fillMaxSize().background(bg)) {
        Canvas(Modifier.fillMaxSize()) {
            drawRect(Brush.radialGradient(listOf(glow1, Color.Transparent), center = Offset(size.width * 0.1f, 0f), radius = size.width * 0.95f))
            drawRect(Brush.radialGradient(listOf(glow2, Color.Transparent), center = Offset(size.width, size.height * 0.95f), radius = size.width * 0.85f))
            val step = 26.dp.toPx(); val r = 1.1.dp.toPx()
            var y = step / 2
            while (y < size.height) {
                var x = step / 2
                while (x < size.width) { drawCircle(dot, r, Offset(x, y)); x += step }
                y += step
            }
        }
        content()
    }
}

/* ---------- reusable pieces ---------- */

@Composable fun Modifier.panel(shape: Shape = RoundedCornerShape(20.dp), selected: Boolean = false): Modifier {
    val cs = MaterialTheme.colorScheme
    val dark = LocalDark.current
    val bg = if (selected) cs.primary.copy(alpha = .16f) else cs.surface
    val bd: Brush = if (selected) SolidColor(cs.primary)
    else if (dark) Brush.linearGradient(listOf(Color(0xFF4F6BFF).copy(alpha = .55f), Color(0xFF22E3FF).copy(alpha = .16f)))
    else SolidColor(cs.outline)
    val base = if (dark) this else this.shadow(5.dp, shape, ambientColor = Color(0xFF3B5BFF).copy(alpha = .10f), spotColor = Color(0xFF3B5BFF).copy(alpha = .20f))
    return base.clip(shape).background(bg).border(1.dp, bd, shape)
}

@Composable fun IconBadge(icon: String, tint: Color, size: Dp = 44.dp) {
    val sh = RoundedCornerShape(size * 0.3f)
    Box(Modifier.size(size).clip(sh).background(Brush.linearGradient(listOf(tint.copy(alpha = .34f), tint.copy(alpha = .08f)))).border(1.dp, tint.copy(alpha = .40f), sh), contentAlignment = Alignment.Center) {
        Text(icon, fontSize = (size.value * 0.5f).sp)
    }
}

@Composable fun SectionTitle(text: String) {
    Row(Modifier.padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.width(4.dp).height(18.dp).clip(RoundedCornerShape(2.dp)).background(Brush.verticalGradient(listOf(Color(0xFF4F6BFF), Color(0xFF22D3EE)))))
        Spacer(Modifier.width(8.dp))
        Text(text, fontWeight = FontWeight.Bold, fontSize = 16.sp)
    }
}

@Composable fun Pill(text: String, filled: Boolean = false, onClick: () -> Unit) {
    val sh = RoundedCornerShape(50)
    val base = if (filled) Modifier.clip(sh).background(accentBrush()) else Modifier.panel(sh)
    Box(base.clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 8.dp), contentAlignment = Alignment.Center) {
        Text(text, fontSize = 13.sp, fontWeight = FontWeight.Medium, color = if (filled) Color.White else MaterialTheme.colorScheme.onSurface)
    }
}

@Composable fun RoundBtn(text: String, onClick: () -> Unit) {
    Box(Modifier.size(40.dp).panel(RoundedCornerShape(50)).clickable(onClick = onClick), contentAlignment = Alignment.Center) { Text(text, fontSize = 18.sp) }
}

@Composable fun GradientButton(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(modifier.clip(RoundedCornerShape(16.dp)).background(accentBrush()).clickable(onClick = onClick).padding(horizontal = 30.dp, vertical = 14.dp), contentAlignment = Alignment.Center) {
        Text(text, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
    }
}

/* floating pill navigation: selected tab expands with a gradient capsule */
@Composable fun FloatingNav(items: List<Pair<String, String>>, selected: String, labelOf: (String) -> String, onSel: (String) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp).panel(RoundedCornerShape(32.dp)).padding(6.dp),
        verticalAlignment = Alignment.CenterVertically) {
        items.forEach { (k, i) ->
            val on = k == selected
            val w by animateFloatAsState(if (on) 2.5f else 1f, label = "navw")
            Box(Modifier.weight(w).height(48.dp).clip(RoundedCornerShape(24.dp))
                .then(if (on) Modifier.background(accentBrush()) else Modifier).clickable { onSel(k) }, contentAlignment = Alignment.Center) {
                if (on) Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(i, fontSize = 18.sp); Spacer(Modifier.width(6.dp))
                    Text(labelOf(k), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp, maxLines = 1)
                } else Text(i, fontSize = 21.sp)
            }
        }
    }
}
